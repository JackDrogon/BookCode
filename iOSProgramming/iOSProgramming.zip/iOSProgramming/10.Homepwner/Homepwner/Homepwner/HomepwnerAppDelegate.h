#import <UIKit/UIKit.h>

@interface HomepwnerAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
