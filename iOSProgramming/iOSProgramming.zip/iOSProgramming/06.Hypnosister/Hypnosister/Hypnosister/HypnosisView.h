#import <Foundation/Foundation.h>


@interface HypnosisView : UIView
{
    
}

@end
