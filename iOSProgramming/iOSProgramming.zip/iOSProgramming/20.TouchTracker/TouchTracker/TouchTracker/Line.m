#import "Line.h"

@implementation Line

@synthesize begin, end;

@end
