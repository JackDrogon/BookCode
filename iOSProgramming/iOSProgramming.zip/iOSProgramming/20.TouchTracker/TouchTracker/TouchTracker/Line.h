#import <Foundation/Foundation.h>

@interface Line : NSObject
{
	CGPoint begin;
	CGPoint end;
}
@property (nonatomic) CGPoint begin;
@property (nonatomic) CGPoint end;

@end
