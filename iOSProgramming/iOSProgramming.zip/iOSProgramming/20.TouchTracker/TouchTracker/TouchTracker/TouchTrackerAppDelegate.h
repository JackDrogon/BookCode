#import <UIKit/UIKit.h>

@interface TouchTrackerAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
