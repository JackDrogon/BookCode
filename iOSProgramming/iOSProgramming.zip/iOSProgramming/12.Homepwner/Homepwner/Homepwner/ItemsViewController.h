#import <Foundation/Foundation.h>


@interface ItemsViewController : UITableViewController
{
}

- (IBAction)addNewPossession:(id)sender;

@end
