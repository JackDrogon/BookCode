#import <Foundation/Foundation.h>


@interface HypnosisViewController : UIViewController <UIAccelerometerDelegate>
{

}

@end
