#import <UIKit/UIKit.h>

@interface NerdfeedAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
