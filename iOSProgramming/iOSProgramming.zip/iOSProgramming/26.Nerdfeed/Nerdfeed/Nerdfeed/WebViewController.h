#import <Foundation/Foundation.h>


@interface WebViewController : UIViewController
{
    
}

@property (nonatomic, readonly) UIWebView *webView;

@end
