#import <Foundation/Foundation.h>

NSString *pathInDocumentDirectory(NSString *fileName);