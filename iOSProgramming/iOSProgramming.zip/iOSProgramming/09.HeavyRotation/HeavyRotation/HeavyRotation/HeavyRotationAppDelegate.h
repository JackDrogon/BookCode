#import <UIKit/UIKit.h>

@interface HeavyRotationAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
