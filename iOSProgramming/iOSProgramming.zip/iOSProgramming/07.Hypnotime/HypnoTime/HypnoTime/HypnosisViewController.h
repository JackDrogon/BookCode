#import <Foundation/Foundation.h>


@interface HypnosisViewController : UIViewController
{
    
}

@end
